YK CIVIL CONTRACTOR WEBSITE

Files:
- index.html: responsive starter website

Preview:
Open index.html in a web browser.

Before publishing:
1. Check all phone, WhatsApp, email and address details.
2. Replace the three gallery placeholders with your real project photos.
3. Buy a domain only after checking its availability and renewal price.
4. Upload index.html to a hosting provider, or use a static hosting service.
5. Add the published domain to Google Search Console to request indexing.

Note: This package creates the website files, but it does not itself buy a domain or publish the website online.
